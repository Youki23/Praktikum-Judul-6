<?php
/**
 * Praktikum 6: Implementasi Komunikasi Data Asinkron Menggunakan AJAX dan Fetch API
 * File: config/database.php
 * Konfigurasi koneksi basis data menggunakan PDO.
 */

class Database {
    private string $host = '127.0.0.1';
    private string $db_name = 'db_mahasiswa';
    private string $username = 'root';
    private string $password = '';
    private int $port = 3306;
    private ?PDO $conn = null;

    public function getConnection(): PDO {
        if ($this->conn === null) {
            $dsn = "mysql:host={$this->host};port={$this->port};dbname={$this->db_name};charset=utf8mb4";
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ];

            try {
                $this->conn = new PDO($dsn, $this->username, $this->password, $options);
            } catch (PDOException $e) {
                throw new PDOException("Koneksi ke basis data gagal: " . $e->getMessage(), (int)$e->getCode());
            }
        }

        return $this->conn;
    }
}

